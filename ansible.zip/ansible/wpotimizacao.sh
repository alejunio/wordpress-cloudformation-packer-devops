#!/bin/bash

## OTIMIZACAO SYSCTL.CONF
cat > /etc/sysctl.conf<<EOF
fs.file-max = 1000000
fs.inotify.max_user_watches = 1000000
vm.swappiness = 10
net.ipv4.ip_forward = 0
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
kernel.sysrq = 0
kernel.core_uses_pid = 1
kernel.msgmnb = 65535
kernel.msgmax = 65535
kernel.shmmax = 68719476736
kernel.shmall = 4294967296
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_mem = 8388608 8388608 8388608
net.ipv4.tcp_rmem = 4096 87380 8388608
net.ipv4.tcp_wmem = 4096 65535 8388608
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_challenge_ack_limit = 1073741823
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_keepalive_time = 15
net.ipv4.tcp_max_orphans = 262144
net.ipv4.tcp_max_syn_backlog = 262144
net.ipv4.tcp_max_tw_buckets = 400000
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 2
net.ipv4.tcp_sack = 1
net.ipv4.route.flush = 1
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 8388608
net.core.wmem_default = 8388608
net.core.netdev_max_backlog = 262144
net.core.somaxconn = 65535
EOF
sysctl -q -p
#################################################################################


## OTIMIZACAO file-max
cat > /proc/sys/fs/file-max<<EOF
fs.file-max=100000
EOF
#################################################################################


## OTIMIZACAO limits.conf
cat > /etc/security/limits.conf<<EOF
# Limits MySQL
mysql soft nofile 100000
mysql hard nofile 100000

# Limits Nginx
nginx soft nofile 100000
nginx hard nofile 100000
www-data soft nofile 100000
www-data hard nofile 100000

# Limits root
root soft nofile 100000
root hard nofile 100000
EOF
#################################################################################


# OTIMIZACAO MYSQL
cat > /etc/mysql/my.cnf<<EOF
[client]
port		= 3306
socket		= /var/run/mysqld/mysqld.sock

[mysqld_safe]
socket		= /var/run/mysqld/mysqld.sock
nice		= 0

[mysqld]
user		= mysql
pid-file	= /var/run/mysqld/mysqld.pid
socket		= /var/run/mysqld/mysqld.sock
port		= 3306
basedir		= /usr
datadir		= /var/lib/mysql
tmpdir		= /tmp
lc_messages_dir	= /usr/share/mysql
lc_messages	= en_US
skip-external-locking
performance_schema = ON
bind-address = ::ffff:127.0.0.1


#Fine Tuning
max_connections		= 100
connect_timeout		= 5
wait_timeout		= 60
max_allowed_packet	= 16M
thread_cache_size   = 128
sort_buffer_size	= 4M
bulk_insert_buffer_size	= 16M
tmp_table_size		= 32M
max_heap_table_size	= 32M


# MyISAM
myisam_recover_options = BACKUP
key_buffer_size		 = 64M
open-files-limit	 = 500000
table_open_cache	 = 500000
myisam_sort_buffer_size	= 256M
concurrent_insert	 = 2
read_buffer_size	 = 2M
read_rnd_buffer_size = 1M

#Query Cache Configuration
query_cache_limit		= 128K
query_cache_size		= 0
query_cache_type		= 0

#Logging and Replication
#general_log_file        = /var/log/mysql/mysql.log
#general_log             = 1
# we do want to know about network errors and such
log_warnings		= 2

# Enable the slow query log to see queries with especially long duration
slow_query_log = 1
slow_query_log_file	= /var/log/mysql/mariadb-slow.log
long_query_time = 10
#log_slow_rate_limit	= 1000
#log_slow_verbosity	= query_plan


default_storage_engine	= InnoDB

# innodb_log_file_size = innodb_buffer_pool_size / 8
innodb_log_file_size	= 128M
# innodb_buffer_pool_size = RAM / 2
innodb_buffer_pool_size	= 1G
# innodb_log_buffer_size = innodb_buffer_pool_size / 4
innodb_log_buffer_size	= 256M

innodb_file_per_table	= 1
innodb_open_files	= 500000
innodb_io_capacity	= 500000
innodb_flush_method	= O_DIRECT

[mysqldump]
quick
quote-names
max_allowed_packet	= 16M

[mysql]
#no-auto-rehash	

[isamchk]
key_buffer		= 16M

!include /etc/mysql/mysql.cnf
!includedir /etc/mysql/conf.d/
EOF
#################################################################################

# Otimizacao Nginx 
cat > /etc/nginx/nginx.conf<<EOF
user www-data;
worker_processes auto;
pid /run/nginx.pid;
worker_rlimit_nofile 65535;
include /etc/nginx/modules-enabled/*.conf;

events {
	worker_connections 10000;
	multi_accept       on;
}

http {

	charset                utf-8;
    sendfile               on;
    tcp_nopush             on;
    tcp_nodelay            on;
    server_tokens          off;
    log_not_found          off;
    types_hash_max_size    2048;
    types_hash_bucket_size 64;
    client_max_body_size   16M;

    #MIME
	include /etc/nginx/mime.types;
	default_type application/octet-stream;
	
    # SSL 
	ssl_protocols TLSv1 TLSv1.1 TLSv1.2; # Dropping SSLv3, ref: POODLE
    ssl_ciphers            ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
	ssl_prefer_server_ciphers on;
    ssl_session_timeout    1d;
    ssl_session_cache      shared:SSL:10m;
    ssl_session_tickets    off;

    # Logs 
	access_log /var/log/nginx/access.log;
	error_log /var/log/nginx/error.log;


    # OCSP Stapling
    ssl_stapling           on;
    ssl_stapling_verify    on;
    resolver               1.1.1.1 1.0.0.1 8.8.8.8 8.8.4.4 208.67.222.222 208.67.220.220 valid=60s;
    resolver_timeout       2s;


	##
	# Virtual Host Configs
	##

	include /etc/nginx/conf.d/*.conf;
	include /etc/nginx/sites-enabled/*;
}
EOF
#################################################################################

## Personalizacao Bash
cat >> /home/ubuntu/.bashrc<<EOF
# Install SSL WordPress
alias wpssl='sudo bash /home/projeto/ansible/sslgenerate.sh'
EOF
#################################################################################

# Banner Shell
sudo rm /etc/update-motd.d/00-header
sudo cat > /etc/update-motd.d/00-header<<EOF
printf "\n"
printf "## Stack WordPress Optimization // Astack Solutions IT\n"
printf "\n"
EOF
sudo chown root:root /etc/update-motd.d/00-header



sudo rm /etc/update-motd.d/10-help-text
sudo cat > /etc/update-motd.d/10-help-text<<EOF
printf "\n"
printf " * Documentation:  https://wiki.astack.com\n"
printf " * Support:        support@astack.com\n"
printf " * Website:        https://astack.com\n"
EOF
sudo chown root:root /etc/update-motd.d/10-help-text



sudo rm /etc/update-motd.d/90-updates-available
sudo cat > /etc/update-motd.d/90-updates-available<<EOF
printf " * Command Install SSL Domain: sslwp\n"
printf " * Password MySQL: /home/ubuntu/credentials\n"
printf " * Password User SFTP: /home/ubuntu/credentials\n"
printf " * Folder WordPress: /home/wordpress/public_html\n"
printf "\n"
EOF
sudo chown root:root /etc/update-motd.d/90-updates-available
#################################################################################

